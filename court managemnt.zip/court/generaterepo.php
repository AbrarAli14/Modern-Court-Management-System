
<?php
	require_once('auth.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information system</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css"></style>
  		<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #000000;
}

li {
    float: left;
font-size:large;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 16px 18px;
    text-decoration: none;
	font-size:20px;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #ffffff;
	color:#000000;
	
	text-decoration:none;
	font-size:21px;
	
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
	font-size:medium;
    background-color: #000000;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
	
    text-align: left;
	
}

.dropdown-content a:hover {background-color: #f9f9f9
color:red;}

.dropdown:hover .dropdown-content {
    display: block;
	
}

</style>
  
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu1">
        <li class="current"><a href="officer.php">Home</a></li>
       <li class="dropdown">
    <a href="javascript:void(0)" class="">Registration</a>
	<div class="dropdown-content">
      <a href="regcase.php">New case registration</a>
	  <a href="regadvocator.php">Register Advocator</a>
     
      
    </div>
		     </li>
        <li><a href="viewappo.php">View Appointment </a></li>
        <li><a href="generaterepo.php">Generate Report </a></li>
		<li><a href="searchinfo.php">Search customer Information </a></li>
      
		<li><a href="login.php">logout</a></li>
        
      </ul>
    </div><!--close menubar-->
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            
             <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			
			<div id="menubar1">
	
	
	   
	

	  <table width="212" height="36">
        <tr>
          <th width="204"  scope="row"><span class="style17">Judge and Court</span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                  </marquee>
                    <marquee direction="up">
                    <p>&nbsp;</p>
                    </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <p>&nbsp;</p>
            <ul id="menu">
        
        <li></li>
	  </ul>
			
          </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	
	 
	  <div id="content">
	     <table width="495">
       
      </table>
       <script type="text/javascript">
function showDiv(prefix,chooser) 
{
        for(var i=0;i<chooser.options.length;i++) 
		{
        	var div = document.getElementById(prefix+chooser.options[i].value);
            div.style.display = 'none';
        }
 
		var selectedOption = (chooser.options[chooser.selectedIndex].value);
		if(selectedOption == "1")
		{
			displayDiv(prefix,"1");
		}
		if(selectedOption == "2")
		{
			displayDiv(prefix,"2");
		}
		if(selectedOption == "3")
		{
			displayDiv(prefix,"3");
		}
		if(selectedOption == "4")
		{
			displayDiv(prefix,"4");
		}
		if(selectedOption == "5")
		{
			displayDiv(prefix,"5");
		}
} 
function displayDiv(prefix,suffix) 
{
        var div = document.getElementById(prefix+suffix);
        div.style.display = 'block';
}
</script>
	 <table id="contentbox">
		<tr>
			<td id="content">
				<div id="report">
				Select Types of report:
				<select name="portal" id="cboOptions" onChange="showDiv('div',this)">
					<option value="1">...</option>
					<option value="2">Open case</option>
					<option value="4">Closed case</option>
					<option value="5"> Appointed case</option>
				</select>
				<br /><br />
						  
				<div id="div1" style="display:none;"></div>	
				<div id="div2" style="display:none;">
					<form action="" method="post" >
					
						
						<?php 
						include('Connection.php');
						
	$sel=mysqli_query($conn,"SELECT * FROM newcase where file_status='open'");
			echo '<table style="border-radius:10px;" bgcolor="#FFE4C4" border="1"><tr>';
			echo '<th bgcolor="#000000" colspan=9 ><font color="#F0FFFF" size=5 >new case report</font></th></tr>';
			echo '<tr><th bgcolor="#336699"><font color="white" size="4">Accuser Name</th>
					<th bgcolor="#336699"><font color="white" size="4"> Plaintif Name </th>
			<th bgcolor="#336699"><font color="white" size="4">File Number</th>
			<th bgcolor="#336699"><font color="white" size="4"> Judge ID </th>
			<th bgcolor="#336699"><font color="white" size="4"> Advocator ID </th>
			<th bgcolor="#336699"><font color="white" size="4">Case Type </th>
			
			<th bgcolor="#336699"><font color="white" size="4">Case Hierarchy </th>
			<th bgcolor="#336699"><font color="white" size="4">File Status </th>
		
			</tr>';
			
			$intt=mysqli_num_rows($sel);
			echo"<br>";
			if($intt==0)
			{
				echo '<p><font size=4 color=red>Empty List</font></p>';
			}
			else{
			while($row=mysqli_fetch_array($sel)){
  print ("<tr>");
  print ("<td><font size='4'>" . $row['accuser_name'] . "</td>");
  print ("<td><font size='4'>" . $row['plaintif_name'] . "</td>");
	 print ("<td><font size='4'>" . $row['file_number'] . "</td>");
print ("<td><font size='4'>" . $row['judge_id'] . "</td>");
print ("<td><font size='4'>" . $row['advocator_id'] . "</td>");
print ("<td><font size='4'>" . $row['case_type'] . "</td>");

print ("<td><font size='4'>" . $row['case_hierarchy'] . "</td>");
print ("<td><font size='4'>" . $row['file_status'] . "</td>");
 
  print ("</tr>");
  }}
print( "</table>");
if($intt!=0)
{
	echo'<p valign="bottom" align="right"><form><input type="button" style="width:30%;height:30px;color:#2E8B57;
					   text-transform:capitalize;Font-weight:bolder;font-size:15px"; value="Print" onclick="window.print();"></form></p>';					
}
			
						?>
					</form>
				</div>		
				<div id="div4" style="display:none;">
					<form action="" method="post" >
					
										<?php 
						include('connection.php');
						
	$sel1=mysqli_query($conn,"SELECT * FROM decision ");
			
			echo '<table style="border-radius:10px;" bgcolor="#FFE4C4" border="1"><tr>';
			echo '<th bgcolor="#000000" colspan=9 ><font color="#F0FFFF" size=5 >Closed report</font></th></tr>';
			echo '<tr><th bgcolor="#336699"><font color="white" size="4">Accuser Name</th>
					<th bgcolor="#336699"><font color="white" size="4"> Plaintif Name </th>
			<th bgcolor="#336699"><font color="white" size="4">File Number</th>
			<th bgcolor="#336699"><font color="white" size="4"> Judge ID </th>
			<th bgcolor="#336699"><font color="white" size="4"> Advocator ID </th>
			<th bgcolor="#336699"><font color="white" size="4">Case Type </th>
			
			<th bgcolor="#336699"><font color="white" size="4">Case Hierarchy </th>
			<th bgcolor="#336699"><font color="white" size="4">File Status </th>
		
			</tr>';
			$intt=mysqli_num_rows($sel1);
			echo"<br>";
			if($intt==0)
			{
				echo '<p><font size=4 color=red>Empty List</font></p>';
			}
			else{
			
			while($row=mysqli_fetch_array($sel1)){
  print ("<tr>");
  print ("<td><font size='4'>" . $row['accuser_name'] . "</td>");
  print ("<td><font size='4'>" . $row['asex'] . "</td>");
	 print ("<td><font size='4'>" . $row['defender_name'] . "</td>");
print ("<td><font size='4'>" . $row['dsex'] . "</td>");
print ("<td><font size='4'>" . $row['judge_id'] . "</td>");
print ("<td><font size='4'>" . $row['file_number'] . "</td>");

print ("<td><font size='4'>" . $row['case_type'] . "</td>");
print ("<td><font size='4'>" . $row['decision'] . "</td>");
print ("<td><font size='4'>" . $row['decision_date'] . "</td>");
 
  print ("</tr>");
  }
  }
print( "</table>");
			
if($intt!=0)
{
	echo'<p valign="bottom" align="right"><form><input type="button" style="width:30%;height:30px;color:#2E8B57;
					   text-transform:capitalize;Font-weight:bolder;font-size:15px"; value="Print" onclick="window.print();"></form></p>';					
}
			
						?>
					</form>
				</div>
				<div id="div4" style="display:none;">
					<form action="" method="post" >
					
						<?php 
						include('Connection.php');
					
	$sel11=mysqli_query($conn,"SELECT * FROM appintment where file_status='appointed'");
			echo '<table style="border-radius:10px;" bgcolor="#FFE4C4" border="1"><tr>';
			echo '<th bgcolor="#000000" colspan=9 ><font color="#F0FFFF" size=5 >Appointed report</font></th></tr>';
			echo '<tr><th bgcolor="#336699"><font color="white" size="4">Accuser Name</th>
					<th bgcolor="#336699"><font color="white" size="4"> Plaintif Name </th>
			<th bgcolor="#336699"><font color="white" size="4">File Number</th>
			<th bgcolor="#336699"><font color="white" size="4"> Judge ID </th>
			<th bgcolor="#336699"><font color="white" size="4"> Advocator ID </th>
			<th bgcolor="#336699"><font color="white" size="4">Case Type </th>
			
			<th bgcolor="#336699"><font color="white" size="4">Case Hierarchy </th>
			<th bgcolor="#336699"><font color="white" size="4">File Status </th>
		
			</tr>';
			
			$intt=mysqli_num_rows($sel11);
			echo"<br>";
			if($intt==0)
			{
				echo '<p><font size=4 color=red>Empty List</font></p>';
			}
			else{
			while($row=mysqli_fetch_array($sel11)){
  print ("<tr>");
  print ("<td><font size='4'>" . $row['accuser_name'] . "</td>");
  print ("<td><font size='4'>" . $row['plaintif_name'] . "</td>");
	 print ("<td><font size='4'>" . $row['file_number'] . "</td>");
print ("<td><font size='4'>" . $row['judge_id'] . "</td>");
print ("<td><font size='4'>" . $row['advocator_id'] . "</td>");
print ("<td><font size='4'>" . $row['case_type'] . "</td>");

print ("<td><font size='4'>" . $row['case_hierarchy'] . "</td>");
print ("<td><font size='4'>" . $row['file_status'] . "</td>");
 
  print ("</tr>");
  }
print( "</table>");
if($intt!=0)
{
	echo'<p valign="bottom" align="right"><form><input type="button" style="width:30%;height:30px;color:#2E8B57;
					   text-transform:capitalize;Font-weight:bolder;font-size:15px"; value="Print" onclick="window.print();"></form></p>';					
}
			}
						?>

					
					</form>
						</div>
				<div id="div5" style="display:none;">
					<form action="" method="post" >
				</div>
				</div>
			</td>
		</tr>
	</table>
</td>
	</tr>
	 </table>              
<!--End Body of section-->
</table>
	  </div>
	  <!--close sidebar_container-->
    </div>
	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By RegularInformation Technology Students</i></font></h3>
        </li>
</ul>
	<!--close sidebar-->
</body>
</html>
