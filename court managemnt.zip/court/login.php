
<?php
	//Start session
	session_start();
	include('connection.php');
	//Unset the variables stored in session
	unset($_SESSION['un']);
	unset($_SESSION['fname']);
    unset($_SESSION['lname']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information Management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style8 {color: #000000; font-weight: bold; font-style: italic;}
.style10 {font-style: italic; color: #00FFFF; font-weight: bold; }
.style11 {	color: #0000CC;
	font-size: 12px;
}
-->
  </style>
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1202" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us </a></li>
        <li><a href="cntct.php">Contact Us</a></li>
		   <li><a href="givecomment.php">Give comment</a></li>
        <li><a href="feedback.php">View feedback</a></li>
        <li class="current"><a href="login.php">Login</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
 <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			 <ul id="menu">
        
        <li><a href="mission.php">Our Mission </a></li>
        
        
      </ul>
	  
			 <ul id="menu">
        
        <li><a href="vission.php">Our Vission </a></li>
        
        
      </ul>
			<table width="200" height="250">
            
            </table>
			<p>&nbsp;</p>
			<div id="menubar1">

	  
			</div>
			
			
          </div><!--close sidebar_item--> 
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	<div>
      <ul class="slideshow">
       <li><img width="975" height="350" src="images/jimma.jpg"/></li>
		<li><img width="975" height="350" src="images/download.jpg"/></li>
		<li><img width="970" height="320" src="images/ima.jpg"/></li>
		<li><img width="975" height="345" src="images/do.jpg"/></li>
      </ul>   	 
	 </div>
	 
	  <div id="content1">
        <div class="content_item">

		  <form action='loginn.php' method='post'>
		  
		  <table width="367" height="98">
            <tr>
              <th height="92" scope="row"><img src="images/loooogg.jpg" alt="" width="296" height="80" /></th>
            </tr>
          </table>
		  <table width="392" height="124">
            
            <tr>
              <th width="238" align="right" scope="row">User Name </th>
              <td width="142"><label>
                <input name="uname" type="text" id="uname" />
              </label></td>
            </tr>
            <tr>
              <th align="right" scope="row">Password</th>
              <td><label>
                <input name="pword" type="password" id="pword" />
              </label></td>
            </tr>
            <tr>
              <th height="30" colspan="2" align="right" scope="row"><label>
                <input type="submit" name="Submit" value="Login" />
          
            </tr>
          </table>
		   
		  </form>
         <a href="forget.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 <font color="red">Forget Password?</font></a>
        </div>
	  </div>
	  <ul id="menu">
       
        <li class="style9  style18">
          <h2 class="style19" align="center">Copyright©2022 Jimma town Court Management System </h2>
        </li>
      </ul>
	  <!--close sidebar_container-->
    </div>
	<!--close sidebar-->
</body>
</html>
