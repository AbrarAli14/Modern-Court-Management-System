<?php
$conn=mysqli_connect("localhost","root","") or die(mysqli_error());
	$sdb=mysqli_select_db($conn,"court") or die(mysqli_error()); 
if(isset($_GET['status']))
{
	$status=$_GET['status'];
	
	$select_status=mysqli_query($conn,"select * from account where User_id='$status'");
	while($row=mysqli_fetch_object($select_status))
	{
		$st=$row->status;
	
	if($st=='off')
	{
		$status2='on';
	}
	else
	{
		$status2='off';
	}
	$update=mysqli_query($conn,"update account set status='$status2' where User_id='$status' ");
	if($update)
	{
		header("Location:editua.php");
	}
	else
	{
		echo mysqli_error($conn);
	}
	}
	?>
     
    <?php
}
?>