
<?php
	//Start session
	session_start();
	include('connection.php');
	//Unset the variables stored in session
	unset($_SESSION['un']);
	unset($_SESSION['fname']);
    unset($_SESSION['lname']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information Management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style8 {color: #000000; font-weight: bold; font-style: italic;}
.style10 {font-style: italic; color: #00FFFF; font-weight: bold; }
.style11 {	color: #0000CC;
	font-size: 12px;
}
-->
  </style>
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1202" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu">
         <li ><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us </a></li>
        <li><a href="cntct.php">Contact Us</a></li>
		  <li><a href="viewappc.php">View Appointment </a></li>
		   <li><a href="givecomment.php">Give comment</a></li>
        <li  class="current"><a href="login.php">Login</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
 <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			 <ul id="menu">
        
        <li><a href="mission.php">Our Mission </a></li>
        
        
      </ul>
	  
			 <ul id="menu">
        
        <li><a href="vission.php">Our Vission </a></li>
        
        
      </ul>
			<table width="200" height="250">
            
            </table>
			<p>&nbsp;</p>
			<div id="menubar1">

	  
			</div>
			
			
          </div><!--close sidebar_item--> 
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	<div>
      <ul class="slideshow">
       <li><img width="975" height="350" src="images/jimma.jpg"/></li>
		<li><img width="975" height="350" src="images/download.jpg"/></li>
		<li><img width="975" height="350" src="images/ima.jpg"/></li>
		<li><img width="975" height="350" src="images/do.jpg"/></li>
      </ul>   	 
	 </div>
	 
	  <form id="form1" name="login" method="POST" action="forget.php" onsubmit="return validateForm()">
 <div style="background-color:#DEB887;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;"> 
 <div style="float:left;" ><strong><font color="white" size="2px">Forget Password</font></strong></div>
 
 </div>
 <?php
if(isset($_POST['changepassword']))
{
	$uid = $_POST['user_id'];
$newpass = $_POST['new_password'];
$confirmpass = $_POST['confirm_password'];
$connect=mysqli_connect("localhost","root","");
if(!$connect){
die("error connection to db server".mysqli_error($connect));
}
$dbselect=mysqli_select_db($conn,"court");
if(!$dbselect){
die("error in selecting db ".mysqli_error($dbselect));
}
$query="select * from account where User_id ='$uid' ";
$result=mysqli_query($conn,$query);
if(!$result){
die("query faile".mysqli_error($connect));
}
if(mysqli_num_rows($result)==1){
    if($newpass!=$confirmpass){
	       echo'  <p class="wrong"> Password does not Match!</p>';                                
		   echo' <meta content="5;forget.php" http-equiv="refresh" />';
		   }
		   else
		   {
  $query="update account set password='$newpass' where User_id='$uid'";
        $result=mysqli_query($conn,$query);
		 echo'  <p class="success"> <font color=#008080>Your password has been changed!</font></p>';
         echo' <meta content="5;login.php" http-equiv="refresh" />';  
   }
   }
else
{
 echo'  <p class="wrong"><font color="red">Wrong user id!</font></p>';
 echo' <meta content="5;forget.php" http-equiv="refresh" />';
}
}
?>


  <table width="350" align="center">
  <tr>
    <td colspan="2"><div style="font-family:Arial, Helvetica, sans-serif; color:#FF0000; font-size:12px;">
</div></td>
  </tr>  
  <br><br><br>
		 <tr>
	     <td> User ID:</td>
		 <td><input type="text" name="user_id" required x-moz-errormessage="Enter user id" ></td>
	     </tr>
         <tr>
	     <td>  New Password:</td>
		 <td><input type="password" name="new_password" required x-moz-errormessage="Enter  Password" ></td>
	     </tr>
		 <tr>
	     <td> Confirm Password:</td>
		 <td><input type="password" name="confirm_password" required x-moz-errormessage="Re-type your Password" ></td>
	     </tr>
  <tr>
    <td>&nbsp;</td>
	<br>
    <td><input type="submit" name="changepassword" value="Change Password" class="button_example"/></td>
  </tr>
</table> 
  </form>
</div>
	  <ul id="menu">
       
        <li class="style9  style18">
          <h2 class="style19" align="center">Copyright©2022 Jimma town Court Management System </h2>
        </li>
      </ul>
	  <!--close sidebar_container-->
    </div>
	<!--close sidebar-->
</body>
</html>
