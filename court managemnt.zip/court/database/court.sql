-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2017 at 07:32 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `court`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `User_id` varchar(20) NOT NULL,
  `Fname` varchar(33) NOT NULL,
  `Lname` varchar(33) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `role` varchar(22) NOT NULL,
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `status` varchar(22) NOT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`User_id`, `Fname`, `Lname`, `sex`, `phone`, `role`, `username`, `password`, `status`) VALUES
('0122', 'abe', 'kebeye', 'male', '+251940372819', 'customer', 'abebe', 'kebede', 'on'),
('5', 'mekash', 'alemu', 'male', '0946353678', 'admin', 'ff', 'ff', 'on'),
('6', 'mebi', 'hafte', 'male', '0964563425', 'law_officer', 'cc', 'cc', 'on'),
('7632', 'gg', 'gg', 'male', '0987654322', 'judge', 'gg', 'gg', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `advocator`
--

CREATE TABLE IF NOT EXISTS `advocator` (
  `ID` varchar(10) NOT NULL,
  `Fname` varchar(100) NOT NULL,
  `Mname` varchar(100) NOT NULL,
  `Lname` varchar(100) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `reg_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advocator`
--

INSERT INTO `advocator` (`ID`, `Fname`, `Mname`, `Lname`, `sex`, `age`, `phone`, `reg_date`, `status`) VALUES
('722', 'Gashaw', 'Estifanos', 'Dejen', 'male', 21, '0943566252', '2017-08-09', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
  `file_number` int(11) NOT NULL,
  `judge_id` varchar(20) NOT NULL,
  `case_type` varchar(150) NOT NULL,
  `accuser_name` varchar(100) NOT NULL,
  `plaintif_name` varchar(100) NOT NULL,
  `chlot` varchar(100) NOT NULL,
  `appointmentDate` date NOT NULL,
  `appointmentTime` time NOT NULL,
  `givingDate` date NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`file_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`file_number`, `judge_id`, `case_type`, `accuser_name`, `plaintif_name`, `chlot`, `appointmentDate`, `appointmentTime`, `givingDate`, `status`) VALUES
(1023, '7632', 'Killing', 'Zebene', 'Tekalgn', '10', '2017-08-09', '03:00:00', '2017-08-09', 'decided'),
(2143, '7632', 'Theft', 'mekonn', 'Kabtamu', '10', '2017-08-11', '04:00:00', '2017-08-10', 'undecided');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`message_id`, `user_id`, `name`, `message`) VALUES
(1, '0122', 'abebe', 'hii');

-- --------------------------------------------------------

--
-- Table structure for table `decision`
--

CREATE TABLE IF NOT EXISTS `decision` (
  `accuser_name` varchar(100) NOT NULL,
  `asex` varchar(10) NOT NULL,
  `defender_name` varchar(100) NOT NULL,
  `dsex` varchar(10) NOT NULL,
  `file_number` int(11) NOT NULL,
  `judge_id` varchar(100) NOT NULL,
  `case_type` varchar(100) NOT NULL,
  `decision` text NOT NULL,
  `decision_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `decision`
--

INSERT INTO `decision` (`accuser_name`, `asex`, `defender_name`, `dsex`, `file_number`, `judge_id`, `case_type`, `decision`, `decision_date`) VALUES
('Zebene', 'male', 'Tekalgn', 'male', 1023, '7632', 'Killing', 'Ato Zebene befetsemut wonjel 10 amet yahl tsinu esrat teferdobachewal', '2017-08-09');

-- --------------------------------------------------------

--
-- Table structure for table `newcase`
--

CREATE TABLE IF NOT EXISTS `newcase` (
  `file_number` int(30) NOT NULL AUTO_INCREMENT,
  `accuser_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `plaintif_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `case_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `file_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `open_date` date NOT NULL,
  `judge_id` varchar(20) NOT NULL,
  `advocator_id` varchar(20) NOT NULL,
  `payment` int(25) NOT NULL,
  `case_hierarchy` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `amount_money` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `bill_number` int(11) NOT NULL,
  `file_status` varchar(20) NOT NULL,
  PRIMARY KEY (`file_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2144 ;

--
-- Dumping data for table `newcase`
--

INSERT INTO `newcase` (`file_number`, `accuser_name`, `plaintif_name`, `case_type`, `file_type`, `open_date`, `judge_id`, `advocator_id`, `payment`, `case_hierarchy`, `amount_money`, `bill_number`, `file_status`) VALUES
(344, 'Geteneh', 'Gashaw', 'land debt', 'Work dispute', '2017-08-09', '7632', '722', 200, 'Primary level', '200', 1245, 'open'),
(1023, 'Zebene', 'Tekalgn', 'Killing', 'crime', '2017-08-08', '7632', '722', 200, '400', '200', 1345, 'closed'),
(2143, 'mekonn', 'Kabtamu', 'Theft', 'crime', '2017-08-10', '7632', '722', 200, 'Primary level', '300', 567, 'appointed');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
