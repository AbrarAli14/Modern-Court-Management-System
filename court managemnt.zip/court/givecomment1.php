<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information Management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style10 {
	color: #009933;
	font-size: 36px;
}
.style13 {
	color: #006666;
	font-size: 18px;
}
.style14 {font-style: italic; color: #00FFFF; font-weight: bold; }
.style17 {color: #00FFFF; font-size: 14px; }
.style18 {color: #FFFFFF;
	font-weight: bold;
	font-style: italic;
	font-size: medium;
}
-->
  </style>
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu">
        <li ><a href="customer.php">Home</a></li>
		   <li class="current"><a href="givecomment1.php">Give comment</a></li>
		 

        <li><a href="login.php">Login</a></li>
        
      </ul>
    </div><!--close menubar-->
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            
             <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			
			<div id="menubar1">
	
	
	   
	

	  <table width="212" height="36">
        <tr>
          <th width="204"  scope="row"><span class="style17">Judge and Court</span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                  </marquee>
                    <marquee direction="up">
                    <p>&nbsp;</p>
                    </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <p>&nbsp;</p>
            <ul id="menu">
        
        <li></li>
	  </ul>
			
          </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	
	 
	  <div id="content">
	     <table width="495">
       
      </table>
      <p>
        <!--close content-->
      </p>
     <script type='text/javascript'>
function formValidation(){
//assign the fields
    var firstname=document.getElementById('fname');
	var middlename= document.getElementById('mname');
    var lastname= document.getElementById('lname');
	var user_id = document.getElementById('user_id');
	var phone = document.getElementById('phone');
	var username = document.getElementById('username');
	var password = document.getElementById('password');
	var cpassword = document.getElementById('cpassword');
if(isAlphabet(firstname, "please enter Your First name in letters only")){
if(lengthRestriction(firstname, 3, 30,"for your First name")){
if(isAlphabet(middlename, "please enter Your Middle name in letters only")){
if(lengthRestriction(middlename, 3, 30,"for your Middle name")){
if(isAlphabet(lastname, "please enter Your Last name in letters only")){
if(lengthRestriction(lastname, 3, 30,"for your Last name")){
if(isAlphanumeric(user_id,"Please Enter the Correct ID No (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(user_id, 3, 15,"for your ID No")){
if(isAlphanumeric(password,"Please Enter the Correct Password (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(password, 5, 10,"for your Password")){
if(isAlphanumeric(cpassword,"Please Enter the Correct Confirmation Password (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(cpassword, 5, 10,"for your Confirmation Password")){
if(isAlphanumeric(username,"Please Enter the Correct Username(!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(username, 5, 10,"for your username")){
if(isNumeric(phone, "please enter Number only For Phone Number")){
if(lengthRestriction(phone, 10, 10,"for your Phone number")){
	return true;
	}}}}
	}
	}
	}}
	}}}}
	}}}}
return false;
		
}	
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

function emailValidator(elem, helperMsg){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function isNumeric(elem, helperMsg){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function lengthRestriction(elem, min, max, helperMsg){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		return true;
	}else{
		alert("Please enter between " +min+ " and " +max+ " characters" +helperMsg);
		elem.focus();
		return false;
	}
}
function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z\/]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
	</script>
		<script>
  jQuery(document).ready(function($) {var dateToday = new Date();
var dates = $("#dateStart, #dateEnd").datepicker({
    defaultDate: "+1w",
	dateFormat: 'yy-mm-dd',
    changeMonth: true,
    numberOfMonths: 1,
    minDate: dateToday,
    onSelect: function(selectedDate) {
        var option = this.id == "dateStart" ? "minDate" : "maxDate",
            instance = $(this).data("datepicker"),
            date = $.datepicker.parseDate(instance.settings.dateFormat || $.datepicker.settings.dateFormat, selectedDate, instance.settings);
        dates.not(this).datepicker("option", option, date);
   	 }
	});
});
  </script>


  <form id="form1" method="POST" action="givecomment.php"  onsubmit='return formValidation()'>
 <div style="background-color:#000000;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;"> 
 
 
 <div style="float:left;" ><strong><font color="white" size="2px">Send Your Message</font></strong></div>

 </div>
 
 <table valign='top' align="center">
<tr>
<tr><td>Name:</td><td><input type='text' name='name' id='name' required value=""></td></tr>
	
 <tr>
	       <td> Message:</td>
		   <td><textarea rows="4" cols="30" align="center" name="message" id="message" placeholder='Write message' required x-moz-errormessage="Enter message"></textarea></td>
	     </tr>
</td><br><br>
<tr><td colspan=2 align='center'><input type='submit' name='update' value='send' class="button_example"></tr></td>
</table>
 
 
 
 
 <?php
 include('connection.php');
  if(isset($_POST['update']))
  {
	            $message=$_POST['message'];
				  $name=$_POST['name'];
				
				
				if($name!=""||$message!=""){
  mysqli_query($conn,"insert into comment (user_id,name,message)values('','$name','$message')") or die(mysqli_error($conn));
 // echo'<meta content="3;raccount.php" http-equiv="refresh"/>';
 echo '<p> <font size=4 color=#008080>your message is sent</font></p>';

echo'<meta content="3;givecomment.php" http-equiv="refresh" />';
  }
  else{
	  echo '<p><font color=red size=4>Unsucessfull please try again</font></p>';
  }
  }

  
  ?>
 
 
 
 
 
 
 
  <!--<table width="406" align="center">
	
         <tr>
	       <td class='para1_text' width="220px">First Name:</td>
		   <td><input type="text" name="fname" id="fname" value="<?php echo $fname; ?>"></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"> Middle Name:</td>
		   <td><input type="text" name="mname" id="mname" value="<?php echo $mname; ?>" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"> Last Name:</td>
		   <td><input type="text" name="lname" id="lname" value="<?php echo $lname; ?>" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"> User ID:</td>
		   <td><input type="text" readonly='readonly' value="<?php echo $user_id; ?>" ></td>
	     </tr>
		 <tr>
                
                <td class='para1_text' width="220px">Sex:</td>
                <td><input type="text" name="sex" id="sex" value="<?php echo $sex; ?>" ></td>
              </tr>
		 <tr>
	       <td class='para1_text' width="220px"> Phone No.:</td>
		   <td><input type="text" name="phone_no" id="phone" value="<?php echo $phone_no; ?>" onKeyPress="return isNumberKey(event)" value="<?php echo $fetch[7] ?>" ></td>
	     </tr>
              <tr>
              <td style="padding-top:12px;">Access Type :</td>
		      <td><input type="text" name="level" value="<?php echo $level; ?>" id="actype"></td>
              </tr>
			  <tr>
              <td class='para1_text' width="220px">Block Number :</td>
              <td><input type="text" name="block" value="<?php echo $block; ?>" id="block"></td>
              </tr>
		   <tr>
	       <td class='para1_text' width="220px"> Username:</td>
		   <td><input type="text" name="username" value="<?php echo $username; ?>" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text'> Password:</td>
		   <td><input type="text" name="password" value="<?php echo $password; ?>" id="username"></td>
	     </tr>
		 <tr>
	       <td class='para1_text'> Confirm Password:</td>
		   <td><input type="text" name="confirmpassword" value="<?php echo $confirmpassword; ?>" id="cpassword"></td>
	     </tr>
  <tr>
	<br><br><br>
	<td>&nbsp;</td>
    <td><input type="submit" name="save" value="Save" /></td>
  </tr>
  
  
</table>--> 
  </form>  
  </div>  


</td>
</tr>
</table>
<!--End Body of section-->
</table>
	  </div>
	  <!--close sidebar_container-->
    </div>
	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By Regular Information Technology Students</i></font></h3>
        </li>
</ul>
	<!--close sidebar-->
</body>
</html>
