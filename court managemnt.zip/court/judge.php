
<?php
	require_once('auth.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css"></style>
   <SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
 		<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #000000;
}

li {
    float: left;
font-size:large;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 16px 10px;
    text-decoration: none;
	font-size:19px;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #ffffff;
	color:#000000;
	
	text-decoration:none;
	font-size:21px;
	
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
	font-size:medium;
    background-color: #000000;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
	
    text-align: left;
	
}

.dropdown-content a:hover {background-color: #f9f9f9
color:red;}

.dropdown:hover .dropdown-content {
    display: block;
	
}

</style>
  
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu1">
         <li class="current"><a href="judge.php">Home</a></li>
        <li><a href="recordd.php">Record Decision</a></li>
        <li><a href="giveapp.php">Give Appointment</a></li>
        <li ><a href="viewapp.php">View Appointment</a></li>
		<li><a href="searchinfoj.php">Search Information</a></li>
		<li ><a href="viewassigned.php">View Assigned Case</a></li>
        <li ><a href="not/index.php">send notification</a></li>
		<li><a href="login.php">logout</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
  <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			
			<div id="menubar1">
	
	
	 
	
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	 <table width="212" height="36">
        <tr>
          <th width="204" bgcolor="#000000" scope="row"><span class="style17"><font color="white">Judge and court</font></span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                </marquee>       
                    <marquee direction="up">
                    <p>&nbsp;</p>
                    </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <p>&nbsp;</p>
            </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	
	 
	  <div id="content1">
        <div class="content_item">
		  <h1 class="style12"><em>W<strong>elcome To Judge</strong></em></h1> 
	     
		  <div class="content_image">
		    <img src="images/jimma.jpg" width="450" height="300" alt="image1"/>
	      </div>
		  <table width="497" height="210">
            <tr>
              <th width="278" height="78" bgcolor="#FFFFFF" class="style11" scope="row">&nbsp;</th>
              <th width="95" bgcolor="#FFFFFF" class="style11" scope="row">&nbsp;</th>
              <th width="108" bgcolor="#FFFFFF" class="style11" scope="row"><img src="images/sssssss.jpg" alt="" width="280" height="112"</th>
            </tr>
            <tr>
              <th colspan="3" align="right" scope="row"><p>-Record Final Decision</p>
              <p>-Search customer information</p>
              <p>-Give Appointment</p>
              <p>-send notification</p>
              <p>-View Appointment</p></th>

            </tr>
          </table>
		  <p>&nbsp;</p>
		  <br style="clear:both"/></div>
		  </div>
	  </div>
	 	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By Regular Information Technology Students</i></font></h3>
        </li>
</ul>
	  <!--close sidebar_container-->
    </div>
	<!--close sidebar-->
</body>
</html>
