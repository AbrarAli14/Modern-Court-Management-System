
<?php
	require_once('auth.php');
if(isset($_SESSION['un']))
 {
  $mail=$_SESSION['un'];
 } else {
 ?>

<script>
  alert('You Are Not Logged In !! Please Login to access this page');
  alert(window.location='login.php');
 </script>
 <?php
 }
 ?>

<?php

$user_id=$_SESSION['un'];


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <link rel="stylesheet" type="text/css" media="all" href="includes/jquery/jquery-ui-custom.css" />
<script src="includes/jquery/jquery-1.10.2.js"></script>
<script src="includes/jquery/jquery-ui-custom.js"></script>
  <style type="text/css"></style>
   <SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
 		<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #000000;
}

li {
    float: left;
font-size:large;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 16px 18px;
    text-decoration: none;
	font-size:20px;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #ffffff;
	color:#000000;
	
	text-decoration:none;
	font-size:21px;
	
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
	font-size:medium;
    background-color: #000000;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
	
    text-align: left;
	
}

.dropdown-content a:hover {background-color: #f9f9f9
color:red;}

.dropdown:hover .dropdown-content {
    display: block;
	
}

</style>
  
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu1">
        <li ><a href="judge.php">Home</a></li>
        <li><a href="recordd.php">Record Decision</a></li>
        <li class="current"><a href="giveapp.php">Give Appointment</a></li>
        <li><a href="viewapp.php">View Appointment </a></li>
		<li><a href="searchinfoj.php">Search Information  </a></li>
		li><a href="not/index.php">send notification  </a></li>
		<li><a href="login.php">logout</a></li>
        
      </ul>
    </div><!--close menubar-->
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            
             <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			
			<div id="menubar1">
	
	
	   
	

	  <table width="212" height="36">
        <tr>
          <th width="204"  scope="row"><span class="style17">Judge and Court</span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                  </marquee>
                    <marquee direction="up">
                    <p>&nbsp;</p>
                    </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <p>&nbsp;</p>
            <ul id="menu">
        
        <li></li>
	  </ul>
			
          </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	
	 
	  <div id="content">
	     <table width="495">
       
      </table>
      <p>
        <!--close content-->
      </p>
     <script type='text/javascript'>
function formValidation(){
//assign the fields
    var firstname=document.getElementById('fname');
	var middlename= document.getElementById('mname');
    var lastname= document.getElementById('lname');
	var user_id = document.getElementById('user_id');
	var phone = document.getElementById('phone');
	var username = document.getElementById('username');
	var password = document.getElementById('password');
	var cpassword = document.getElementById('cpassword');
if(isAlphabet(firstname, "please enter Your First name in letters only")){
if(lengthRestriction(firstname, 3, 30,"for your First name")){
if(isAlphabet(middlename, "please enter Your Middle name in letters only")){
if(lengthRestriction(middlename, 3, 30,"for your Middle name")){
if(isAlphabet(lastname, "please enter Your Last name in letters only")){
if(lengthRestriction(lastname, 3, 30,"for your Last name")){
if(isAlphanumeric(user_id,"Please Enter the Correct ID No (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(user_id, 3, 15,"for your ID No")){
if(isAlphanumeric(password,"Please Enter the Correct Password (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(password, 5, 10,"for your Password")){
if(isAlphanumeric(cpassword,"Please Enter the Correct Confirmation Password (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(cpassword, 5, 10,"for your Confirmation Password")){
if(isAlphanumeric(username,"Please Enter the Correct Username(!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(username, 5, 10,"for your username")){
if(isNumeric(phone, "please enter Number only For Phone Number")){
if(lengthRestriction(phone, 10, 10,"for your Phone number")){
	return true;
	}}}}
	}
	}
	}}
	}}}}
	}}}}
return false;
		
}	
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

function emailValidator(elem, helperMsg){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function isNumeric(elem, helperMsg){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function lengthRestriction(elem, min, max, helperMsg){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		return true;
	}else{
		alert("Please enter between " +min+ " and " +max+ " characters" +helperMsg);
		elem.focus();
		return false;
	}
}
function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z\/]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
	</script>
		<script>
  jQuery(document).ready(function($) {var dateToday = new Date();
var dates = $("#dateStart, #dateEnd").datepicker({
    defaultDate: "+1w",
	dateFormat: 'yy-mm-dd',
    changeMonth: true,
    numberOfMonths: 1,
    minDate: dateToday,
    onSelect: function(selectedDate) {
        var option = this.id == "dateStart" ? "minDate" : "maxDate",
            instance = $(this).data("datepicker"),
            date = $.datepicker.parseDate(instance.settings.dateFormat || $.datepicker.settings.dateFormat, selectedDate, instance.settings);
        dates.not(this).datepicker("option", option, date);
   	 }
	});
});
  </script>

  <?php
  include('connection.php');
$ctrl = $_REQUEST['file_number'];
$query="SELECT * FROM newcase where file_number='$ctrl'";
$result=mysqli_query($conn,$query);
$count=mysqli_num_rows($result);
if(!$result){
die("user not registered!".mysqli_error());
}
if($count==1){
while($row=mysqli_fetch_array($result)){
	$r=$row['file_number'];
	$rr=$row['case_type'];
$r0=$row['accuser_name'];
$r1=$row['plaintif_name'];

}
?>
  <form id="form1" method="POST" action="appoint.php"  onsubmit='return formValidation()'>
 <div style="background-color:#336699;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;"> 
 
 
 <div style="float:left;" ><strong><font color="white" size="2px">Give Appointment</font></strong></div>

 </div>
 
 <table valign='top' align="center">
<tr>
<tr><td>File Number:</td><td><input type='text' name='fnumber' id='fnumber' required value="<?php echo "$r"?>"></td></tr>
<tr><td>Case Type:</td><td><input type='text' name='ctype' id='ctype' required value="<?php echo "$rr"?>"></td></tr>
<tr><td>Accuser Name:</td><td><input type='text' name='aname' id='aname' required value="<?php echo "$r0"?>"></td></tr>
<tr><td>Plaintif Name:</td><td><input type='text' name='pname' id='pname'required value="<?php echo "$r1"?>"></td></tr>
<tr><td>judge ID:</td><td><input type='text' name='jid' id='jid'required value="<?php echo $user_id?>"></td></tr>
<tr><td>Chlot:</td><td><input  type='text' id='chlot'required name='chlot'  value=""></td></tr>
<tr><td>Appointment Date:</td><td ><input  type='text' name='appdate'  id='dateStart'required value=""></td></tr>
<tr><td>Appointment Time:</td><td ><input  type='time' name='time'  id='time'required value=""></td></tr>
<tr><td>Giving Date  :</td><td><input type='text' name='date' id='date'required  readonly value="<?php echo date('Y-m-d')?>"></tr></td><br><br>
<tr><td colspan=2 align='center'><input type='submit' name='update' value='appoint' class="button_example"></tr></td>
</table>
 
 
 <?php
}
	  

?>
 
 <?php
  if(isset($_POST['update']))
  {
	            $aname=$_POST['aname'];
				$pname=$_POST['pname'];
		$chilot=$_POST['chlot'];
				$fnumber=$_POST['fnumber'];
				$ctype=$_POST['ctype'];
				$appdate=$_POST['appdate'];
				$time=$_POST['time'];
				$date=$_POST['date'];
				$judge=$_POST['jid'];
				
				if($appdate!=""||$time!=""||$chilot!=""){
  mysqli_query($conn,"insert into appointment values( '$fnumber','$judge','$ctype','$aname','$pname','$chilot','$appdate','$time' 
	,'$date','undecided')") or die(mysqli_error($conn));
 // echo'<meta content="3;raccount.php" http-equiv="refresh"/>';
 echo '<p> <font size=r>Sucessfully appointed</font></p>';
 mysqli_query("update newcase set file_status='appointed' where file_number='$fnumber'");
echo "<script>window.location='giveapp.php';</script>"; 
  }
  else{
	  echo '<p><font color=red size=4>Unsucessfull please try again</font></p>';
  }
  }

  
  ?>
 
 
 
 
 
 
 
  <!--<table width="406" align="center">
	
         <tr>
	       <td class='para1_text' width="220px">First Name:</td>
		   <td><input type="text" name="fname" id="fname" value="<?php echo $fname; ?>"></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"> Middle Name:</td>
		   <td><input type="text" name="mname" id="mname" value="<?php echo $mname; ?>" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"> Last Name:</td>
		   <td><input type="text" name="lname" id="lname" value="<?php echo $lname; ?>" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"> User ID:</td>
		   <td><input type="text" readonly='readonly' value="<?php echo $user_id; ?>" ></td>
	     </tr>
		 <tr>
                
                <td class='para1_text' width="220px">Sex:</td>
                <td><input type="text" name="sex" id="sex" value="<?php echo $sex; ?>" ></td>
              </tr>
		 <tr>
	       <td class='para1_text' width="220px"> Phone No.:</td>
		   <td><input type="text" name="phone_no" id="phone" value="<?php echo $phone_no; ?>" onKeyPress="return isNumberKey(event)" value="<?php echo $fetch[7] ?>" ></td>
	     </tr>
              <tr>
              <td style="padding-top:12px;">Access Type :</td>
		      <td><input type="text" name="level" value="<?php echo $level; ?>" id="actype"></td>
              </tr>
			  <tr>
              <td class='para1_text' width="220px">Block Number :</td>
              <td><input type="text" name="block" value="<?php echo $block; ?>" id="block"></td>
              </tr>
		   <tr>
	       <td class='para1_text' width="220px"> Username:</td>
		   <td><input type="text" name="username" value="<?php echo $username; ?>" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text'> Password:</td>
		   <td><input type="text" name="password" value="<?php echo $password; ?>" id="username"></td>
	     </tr>
		 <tr>
	       <td class='para1_text'> Confirm Password:</td>
		   <td><input type="text" name="confirmpassword" value="<?php echo $confirmpassword; ?>" id="cpassword"></td>
	     </tr>
  <tr>
	<br><br><br>
	<td>&nbsp;</td>
    <td><input type="submit" name="save" value="Save" /></td>
  </tr>
  
  
</table>--> 
  </form>  
  </div>  


</td>
</tr>
</table>
<!--End Body of section-->
</table>
	  </div>
	  <!--close sidebar_container-->
    </div>
	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By Regular Information Technology Students</i></font></h3>
        </li>
</ul>
	<!--close sidebar-->
</body>
</html>
