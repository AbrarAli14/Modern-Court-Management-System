
<?php
	require_once('auth.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information system</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css"></style>
  		<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #000000;
}

li {
    float: left;
font-size:large;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 16px 18px;
    text-decoration: none;
	font-size:20px;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #ffffff;
	color:#000000;
	
	text-decoration:none;
	font-size:21px;
	
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
	font-size:medium;
    background-color: #000000;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
	
    text-align: left;
	
}

.dropdown-content a:hover {background-color: #f9f9f9
color:red;}

.dropdown:hover .dropdown-content {
    display: block;
	
}

</style>
  
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu1">
        <li class="current"><a href="officer.php">Home</a></li>
       <li class="dropdown">
    <a href="javascript:void(0)" class="">Registration</a>
	<div class="dropdown-content">
      <a href="regcase.php">New case registration</a>
	  <a href="regadvocator.php">Register Advocator</a>
     
      
    </div>
		     </li>
        <li><a href="viewappo.php">View Appointment </a></li>
        <li><a href="generaterepo.php">Generate Report </a></li>
		<li><a href="searchinfo.php">Search and Give Apel</a></li>
      
		<li><a href="login.php">logout</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>

            
		<div id="menubar1">
	
	
	  
	 
	   
	
	 
	  <table width="212" height="36">
        <tr>
          <th width="204" bgcolor="#330066" scope="row"><span class="style17">Judge and court</span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                </marquee>                  <marquee direction="up">
                <p>&nbsp;</p>
                </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <ul id="menu">
        
        <li></li>
	  </ul>
			
          </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	

	 
	  <div id="content1">
        <div class="content_item">
		  
		
		  <table width="476" height="239" bordercolor="#0000FF">
            <tr>
              <th width="1" height="37" scope="row">&nbsp;</th>
              <th width="126"  scope="row">&nbsp;</th>
              <th bgcolor="#008080" scope="row"><span class="style13">Function performed by law officer</span></th>
            </tr>
            <tr>
              <th colspan="2" align="left" scope="row"><p>&nbsp;</p>
              <p>&nbsp;    </p></th>
              <th width="333" align="left" scope="row"><p><span class="style14">*Registration of new case and advocator</span></p>
                <p class="style14">*Generating report</p>
                <p class="style14">*View Appointment</p>
                <p class="style14">*Search Information and give Apel</p>
              </th>
            </tr>
          </table>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p>&nbsp;</p>
		  <p><br style="clear:both"/>
	      </p>
        </div>
	  </div>
	  
  <!--close sidebar_container-->
</div>
	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By Summer Information Technology Students</i></font></h3>
        </li>
</ul>
	<!--close sidebar-->
</body>
</html>
