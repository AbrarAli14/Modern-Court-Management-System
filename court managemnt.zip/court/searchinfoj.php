<?php
	require_once('auth.php');
	include ('connection.php');
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information Management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style17 {
	color: #FFFFFF;
	font-weight: bold;
	font-style: italic;
	font-size: medium;
}
.style18 {font-weight: bold}
.style19 {font-style: italic}
-->
  </style>
  		<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #000000;
}

li {
    float: left;
font-size:large;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 16px 10px;
    text-decoration: none;
	font-size:19px;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #ffffff;
	color:#000000;
	
	text-decoration:none;
	font-size:21px;
	
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
	font-size:medium;
    background-color: #000000;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
	
    text-align: left;
	
}

.dropdown-content a:hover {background-color: #f9f9f9
color:red;}

.dropdown:hover .dropdown-content {
    display: block;
	
}

</style>
  
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu1">
            <li ><a href="judge.php">Home</a></li>
        <li ><a href="recordd.php">Record Decision</a></li>
        <li ><a href="giveapp.php">Give Appointment</a></li>
        <li ><a href="viewapp.php">View Appointment </a></li>
		<li class="current"><a href="searchinfoj.php">Search Information  </a></li>
			<li ><a href="viewassigned.php">View Assigned Case  </a></li>
			<li ><a href="not/index.php">send notification</a></li>
		<li><a href="login.php">logout</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            
             <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			
			<div id="menubar1">
	
	
	   
	

	  <table width="212" height="36">
        <tr>
          <th width="204"  scope="row"><span class="style17">Judge and Court</span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                  </marquee>
                    <marquee direction="up">
                    <p>&nbsp;</p>
                    </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <p>&nbsp;</p>
            <ul id="menu">
        
        <li></li>
	  </ul>
			
          </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	
	 
	  <div id="content">
        <div class="content_item">
		
	  <form id="form1" name="login" method="POST" action="searchinfoj.php" onsubmit="return formValidation()">
  	
<p style="font-size:20px;color:red;" >Search  Information</p>
   <table width="399px" valign="top" align="center">
  
  <tr>

	       <td class='para1_text' width="220px"><font color="red">*</font> File number.</td><td><input type="text" name="sid" id="user" x-moz-errormessage="Enter search key." ></td>
	     
	
    <td><input type="submit" name="submitlogin" class="button_example" value="Search" /></td>
  </tr>
</table>
  </form>
<!--Php Script-->  
	 <?php	
	if (isset($_POST['submitlogin'])){ 
	$sid=$_POST['sid'];
	
	if($sid=="")
	{
		echo '<p class="wrong"><font color=red size=4> please enter file number to search</font></p>';
	}	
	else{
	
			$view=mysqli_query($conn,"select * from newcase where file_number='$sid' ");
					$rowCheck = mysqli_num_rows($view);
if($rowCheck<1)
{
echo'<p class="wrong">The information not  found</p>';
echo' <meta content="5;searchinfoj.php" http-equiv="refresh" />';
}
else
{
			while($row = mysqli_fetch_array($view))
            {
			$fnumber=$row['file_number'];
			$aname=$row['accuser_name'];
            $pname=$row['plaintif_name'];
			$ctype=$row['case_type'];
			$odate=$row['open_date'];
				$jid=$row['judge_id'];
				$aid=$row['advocator_id'];
				$ch=$row['case_hierarchy'];
				$fs=$row['file_status'];
            }
			echo"<table align='center' border='2' style='border-radius:15px;border:1px solid #336699;' width='400px' height='300px'>";
			echo"<tr>";
			echo"<th colspan='3' bgcolor='#000000'><font color='white' size='5'>"."Search  Result"."</font><a href='searchinfoj.php'><img align='right' src='img/close_icon.gif' width=35 height=20></a></th>";
			echo"</tr><tr>";
	echo"<td><font face='Times New Roman' size='4' color='green'>File Number:</td><td>".$fnumber.'</td></tr>';
	echo"<td><font face='Times New Roman' size='4' color='green'>Accuser Name:</td><td>".$aname.'</td></tr>';
	echo"<td><font face='Times New Roman' size='4' color='green'>Plaintif Name:</td><td>".$pname.'</td></tr>';
	echo"<td><font face='Times New Roman' size='4' color='green'>Case Type  :</td><td>".$ctype.'</td></tr>';
		echo"<td><font face='Times New Roman' size='4' color='green'>Open date :</td><td>".$odate.'</td></tr>';
		echo"<td><font face='Times New Roman' size='4' color='green'>Judge ID :</td><td>".$jid.'</td></tr>';
		echo"<td><font face='Times New Roman' size='4' color='green'>Advocator ID :</td><td>".$aid.'</td></tr>';
		echo"<td><font face='Times New Roman' size='4' color='green'>Case Hirarchy :</td><td>".$ch.'</td></tr>';
		echo"<td><font face='Times New Roman' size='4' color='green'>File Status :</td><td>".$fs.'</td></tr>';
	echo"</font></table>";
	}
	}
	}
?>
</td>
</table>
<!--End Body of section-->
</table>
	</div>
	  </div>
	  
</div>
	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By Summer Information Technology Students</i></font></h3>
        </li>
</ul>
	<!--close sidebar-->
</body>
</html>
