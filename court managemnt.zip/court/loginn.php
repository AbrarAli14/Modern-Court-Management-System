<?php

session_start();

if(!isset($_SESSION['id']))
header('location: login.php');

$uname=$_POST["uname"];
$pword=$_POST["pword"];
$db = mysqli_connect("localhost","root","") or die ("Error connecting to database.");
if(!$db){
$message= "no connection established";	}		
mysqli_select_db($db,"court") or die("Couldn't select the database.");
$qry="select * from account where username='".$uname."' and password='".$pword ."' and status='on'";
$results = mysqli_query($db,$qry) or die(mysqli_error());


$count=mysqli_num_rows($results);
// If result matched $myusername and $mypassword, table row must be 1 row

if($count<='0'){

if(!$results) {
		$message="<center>Username or password was incorrect! Please try again  </center>";
		include("judge.php");
	} 
}
	else{
	while ($row = mysqli_fetch_array($results)) {
	$_SESSION['un']=$row['User_id'];
		$_SESSION['fname']=$row['Fname'];
		$_SESSION['lname']=$row['Lname'];
		$user=$row['role'];
	if($user=="admin"){
			header('location:AdminPage.php');}
			//echo "admin";
			else if($user=="law_officer"){
			header('location:officer.php');
			//echo "keeper";
			}
			else if($user=="judge"){
			header('location:judge.php');
	}
			else if($user=="custemer"){
			header('location:customer.php');
	}
}
	}
	
	$message="sorry,you are not amember";
	mysqli_close($db);
?>