<?php
//insert.php
if(isset($_POST["firstname"]))
{
	include('conn.php');
	$firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
	$message = mysqli_real_escape_string($conn, $_POST['message']);

	mysqli_query($conn,"insert into `user` (firstname, message) values ('$firstname', '$message')");
}
?>