<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Management System </title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style12 {color: #993399}
.style13 {color: #000000}
.style17 {
	font-size: 18px;
	color: #000000;
}
.style18 {font-family: Georgia, "Times New Roman", Times, serif}
.style19 {font-family: Arial, Helvetica, sans-serif}
.style14 {font-style: italic; color: #00FFFF; font-weight: bold; }
.style15 {	color: #0066FF;
	font-size: 14px;
}
-->
  </style>
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
<img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu">
         <li ><a href="index.php">Home</a></li>
        <li class="current"><a href="about.php">About Us </a></li>
        <li><a href="cntct.php">Contact Us</a></li>
		   <li><a href="givecomment.php">Give comment</a></li>
		    <li><a href="feedback.php">View feedback</a></li>
        <li><a href="login.php">Login</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
  <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			<ul id="menu">
        
        <li><a href="mission.php">Our Mission </a></li>
        
        
      </ul>
			<ul id="menu">
        
        <li><a href="vission.php">Our Vission </a></li>
	  </ul>
			
			<div id="menubar1">
			  <table width="200" height="250">
            
            </table>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
			</div>
			
			
          </div><!--close sidebar_item--> 
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	<div>
      <ul class="slideshow">
     <li><img width="975" height="350" src="images/jimma.jpg"/></li>
		<li><img width="975" height="350" src="images/download.jpg"/></li>
		<li><img width="975" height="350" src="images/ima.jpg"/></li>
		<li><img width="975" height="350" src="images/do.jpg"/></li>
      </ul>   	 
	 </div>
	 
	  <div id="content1">
        <div class="content_item">
		  
		  <h1>Background of the Court </h1> 
	      <p class="style12"><span class="style13">As we visited the work place of; how the court information management system takes place; 
		  we have seen some problems in data processing and handling in jimma town .  During the process there may be many difficulties of 
		  manual processing of files/data. Not only this but also giving comment for one court may be difficult because of distance. 
		  This means there is no online giving comment service before for the court found on the distance. 
Now we are going to develop software that can solve problems of data processing, data handling, give appointment ,assign case ,registering
case and view assigned case etc. we can achieve our aim by using hardware (pc) and software (programming language). The main purpose of doing 
this project is that to save person’s file from damage, store files forever, secure files that must be secured, reduce costs and time. There 
will be data communication from one office to the other. There will be many advantages after the end of our project. The following things will be 
the result after the implementation of the new proposed system we are going to develop.
</p>
		  <br style="clear:both"/></div>
	  </div>
	  <ul id="menu">
       
        <li class="style9  style18">
          <h2 class="style19"align="center">Copyright©2022 Jimma town Court  Management System </h2>
        </li>
      </ul>
	  <!--close sidebar_container-->
    </div>
	<!--close sidebar-->
</body>
</html>
