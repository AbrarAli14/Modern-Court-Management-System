<?php
$conn=mysqli_connect("localhost","root","");//create connection
mysqli_select_db($conn,"court");//to select from the db
?>