<?php
	require_once('auth.php');
	include ('connection.php');
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information Management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
     <SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
<!--
.style17 {
	color: #FFFFFF;
	font-weight: bold;
	font-style: italic;
	font-size: medium;
}
.style18 {font-weight: bold}
.style19 {font-style: italic}
-->
  </style>
  		<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #000000;
}

li {
    float: left;
font-size:large;
}

li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 16px 18px;
    text-decoration: none;
	font-size:20px;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: #ffffff;
	color:#000000;
	
	text-decoration:none;
	font-size:21px;
	
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
	font-size:medium;
    background-color: #000000;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
	
    text-align: left;
	
}

.dropdown-content a:hover {background-color: #f9f9f9
color:red;}

.dropdown:hover .dropdown-content {
    display: block;
	
}

</style>
  
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu1">
        <li><a href="adminpage.php">Home</a></li>
		<li class="dropdown">
    <a href="javascript:void(0)" class="">Create Account</a>
	<div class="dropdown-content">
      <a href="signup.php">Add User Account</a>
	  <a href="editua.php">Update User Account</a>
     
      
    </div>
		     </li>
      <li><a href="viewdecision.php">View Decision </a></li>
        <li><a href="generaterep.php">Generate Report </a></li>
		 <li><a href="search.php">Search customer Information</a></li>
       <li><a href="login.php">logout</a></li>
      </ul>
    </div><!--close menubar-->
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            
             <body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			
			<div id="menubar1">
	
	
	   
	

	  <table width="212" height="36">
        <tr>
          <th width="204" bgcolor="#330066" scope="row"><span class="style17">Judge and court</span></th>
        </tr>
      </table>
	  <div class="sidebar">
          <div class="sidebar_item">
            <table width="222" height="384">
              <tr>
                <th height="28" colspan="2" bgcolor="#999999" scope="row"><p><marquee behavior="scroll" direction="up" onmouseover="this.stop();" onmouseout="this.start();">
                  1. Judges should approach their judicial duties in a spirit of collegiality, cooperation and mutual assistance..</p>
                  <p>2. Judges should conduct court business with due diligence and dispose of all matters before them promptly and efficiently having regard, at all times, to the interests of justice and the rights of the parties before the court..</p>
                  <p>3. Reasons for judgment should be delivered in a timely manner.</p>
				      <p>4. The primary responsibility of judges is the discharge of their judicial duties.</p>
					    
                  <p>5. Judges have a duty to maintain their professional competence in the law.</marquee></p></th>
              </tr>
              <tr>
                <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                </marquee>       
                    <marquee direction="up">
                    <p>&nbsp;</p>
                    </marquee></th>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            
            <p>&nbsp;</p>
            <ul id="menu">
        
        <li></li>
	  </ul>
			
          </div><!--close sidebar_item--> 
        </div>
	  
          
            	 
            </div>
			<!--close sidebar_item--> 
        </div>
			
			
			
          
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	
	 
	  <div id="content">
	     <table width="495">
        <tr>
          <th width="485" height="66" class="style9" scope="row">Create user Account Form </th>
        </tr>
      </table>
      <p>
        <!--close content-->
      </p>
     <td valign="top">
<br>

  <div style="width:480px; height:510px; margin:0 auto; position:relative; border:2px solid rgba(0,0,0,0); -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:25px; -webkit-box-shadow:0 0 18px rgba(0,0,0,0.4); -moz-box-shadow:0 0 18px rgba(0,0,0,0.4); box-shadow:0 0 18px rgba(0,0,0,0.4); margin-top:20px; color:#000000;">
   <SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>
<!--
<!--Form Validation-->
<script type='text/javascript'>
function formValidation(){
//assign the fields
    var firstname=document.getElementById('fname');
	var middlename= document.getElementById('mname');
    var lastname= document.getElementById('lname');
	var user_id = document.getElementById('user_id');
	var phone = document.getElementById('phone');
	var username = document.getElementById('username');
	var password = document.getElementById('password');
	var cpassword = document.getElementById('cpassword');
if(isAlphabet(firstname, "please enter Your First name in letters only")){
if(lengthRestriction(firstname, 3, 30,"for your First name")){
if(isAlphabet(middlename, "please enter Your Middle name in letters only")){
if(lengthRestriction(middlename, 3, 30,"for your Middle name")){
if(isAlphabet(lastname, "please enter Your Last name in letters only")){
if(lengthRestriction(lastname, 3, 30,"for your Last name")){
if(isAlphanumeric(user_id,"Please Enter the Correct ID No (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(user_id, 3, 15,"for your ID No")){
if(isAlphanumeric(password,"Please Enter the Correct Password (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(password, 5, 10,"for your Password")){
if(isAlphanumeric(cpassword,"Please Enter the Correct Confirmation Password (!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(cpassword, 5, 10,"for your Confirmation Password")){
if(isAlphanumeric(username,"Please Enter the Correct Username(!@#$%^&*()*+=~`) Not allowed")){
if(lengthRestriction(username, 5, 10,"for your username")){
if(isNumeric(phone, "please enter Number only For Phone Number")){
if(lengthRestriction(phone, 10, 10,"for your Phone number")){
	return true;
	}}}}
	}
	}
	}}
	}}}}
	}}}}
return false;
		
}	
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

function emailValidator(elem, helperMsg){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function isNumeric(elem, helperMsg){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function lengthRestriction(elem, min, max, helperMsg){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		return true;
	}else{
		alert("Please enter between " +min+ " and " +max+ " characters" +helperMsg);
		elem.focus();
		return false;
	}
}
function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z\/]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}
	</script>
	

  <form id="form1" name="login" method="POST" action="signup.php"  onsubmit='return formValidation()'>
 <div style="background-color:#003366;border-radius:5px;font-family:Arial, Helvetica, sans-serif; color:#000000; padding:5px; height:22px;"> 
 <div style="float:left;" ><strong><font color="white" size="2px">Create User Account</font></strong></div>
<div style="float:right; margin-right:20px; background-color:#cccccc; width:25px;  text-align:center; border-radius:15px; height:12px;">
<a href="adminpage.php" title="Close"><img src="img/close_icon.gif"></a></div> 
 
 </div><br>
 <?php
 if(isset($_POST['save']))
 {
 $level=$_POST['actype'];
 $password=$_POST['password'];
 $cpassword=$_POST['confirmpassword'];
 $query="SELECT * FROM account where username='$_POST[username]'";
$resultw=mysqli_query($conn,$query);
$count=mysqli_num_rows($resultw);
if($count==1){
while($row=mysqli_fetch_array($resultw)){
$user=$row['username'];
}
if($user==$_POST['username'])
{
echo '<p><font color="red" size="3">User Name is used by another user</font></p>';
echo'<meta content="3;signup.php" http-equiv="refresh" />';
}
}
else
{
if($password==$cpassword )
{
$sql="INSERT INTO account (Fname,Lname,User_id,sex,phone,role,username ,password,status)
VALUES
('$_POST[fname]','$_POST[lname]','$_POST[user_id]','$_POST[sex]','$_POST[phone]','$_POST[actype]','$_POST[username]','$_POST[password]','on')";

if (!mysqli_query($conn,$sql))
  {
         echo'  <p class="wrong">Already Registered</p>';
  die('Error: '.'Already Exist'.mysqli_error($conn));
  echo'<meta content="3;signup.php" http-equiv="refresh" />';
  }
  else
  {
	  mysqli_query($conn,$sql);
echo'<p class="success"> Account is created successfully</p>';                                
		   echo' <meta content="6;signup.php" http-equiv="refresh" />';	
}
}
else
{
echo'<br><br><br>';
       echo'  <p class="wrong">Your Password Does not match!!</p>';
	   echo'<meta content="3;signup.php" http-equiv="refresh" />';
	   }
	   
	   }
}
mysqli_close($conn)
?>    
  <table  width="426px" align="center">
	<br><br><br>
         <tr>
	       <td class='para1_text' width="220px"><font color="red">*</font> First Name:</td><td><input type="text" name="fname" id="fname" required x-moz-errormessage="Enter Your First name" ></td>
	     </tr>
		
		 <tr>
	       <td class='para1_text' width="220px"><font color="red">*</font> Last Name:</td><td><input type="text" name="lname" id="lname" required x-moz-errormessage="Enter Your Last name" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text' width="220px"><font color="red">*</font> User ID:</td><td><input type="text" name="user_id" id="user_id" required x-moz-errormessage="Enter Your ID NO" ></td>
	     </tr>
		 <tr>
                
                <td class='para1_text' width="220px"><font color="red">*</font> Sex:</td>
                <td><input type="radio"  name="sex" value="male" title="choose either male by clicking here" required />
                  Male
                  <input type="radio" name="sex" value="female" title='choose female by clicking here' required />
                  Female</td>
              </tr>
		 <tr>
	       <td class='para1_text' width="220px"><font color="red">*</font> Phone No.:</td>
		   <td><input type="text" name="phone" id="phone" maxlength="13"value="+251" onKeyPress="return isNumberKey(event)" required x-moz-errormessage="Enter Your Phone Number" ></td>
	     </tr>
              <tr>
              <td style="padding-top:12px;"><font color="red" size="3">*</font>Role :</td>
              <td style="padding-top:12px;"><select name="actype" required >
            <option value="" >select..</option>
            <option value='admin'>Admin</option>
            <option value='law_officer'>Law officer</option>
				   <option value='judge'>Judge</option>
				   <option value='custemer'>Custemer</option>
				 
                  
                </select></td>
              </tr>
			           <tr>
	       <td class='para1_text' width="220px"><font color="red">*</font> Username:</td><td><input type="text" name="username" required x-moz-errormessage="Enter Username" ></td>
	     </tr>
		 <tr>
	       <td class='para1_text'><font color="red">*</font> Password:</td><td><input type="password" name="password" required x-moz-errormessage="Enter password" id="username"></td>
	     </tr>
		 <tr>
	       <td class='para1_text' ><font color="red">*</font> Confirm Password:</td>
		   <td><input type="password" name="confirmpassword" required x-moz-errormessage="Re-enter password" id="cpassword"></td>
	     </tr>
<tr>
	<td>&nbsp;</td>
    <td ><input type="submit" name="save" value="Save" class="button_example"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset" name="cancel" value="Cancel" class="button_example"/></td>
  </tr>
  
  
</table> 
  </form>
	  </div>
	  <!--close sidebar_container-->
    </div>
	<ul>
       
        <li>
          <h3 align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		  <font color="white" face="Time New Roman"><i>Developed By Regular Information Technology Students</i></font></h3>
        </li>
</ul>
	<!--close sidebar-->
</body>
</html>