<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>IOT store managment system</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style8 {color: #000000; font-weight: bold; font-style: italic;}
-->
  </style>
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
      <img src="images/last2.jpg" alt="image1" width="1202" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu">
        <li ><a href="index.php">Home</a></li>
        <li ><a href="about.php">About Us </a></li>
        <li ><a href="cntct.php">Contact Us</a></li>
        <li><a href="login.php">Login</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
	<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
            <script src="http://24timezones.com/js/swfobject.js" language="javascript"></script>
<script src="http://24timezones.com/timescript/maindata.js.php?city=815322" language="javascript"></script>
<table><tr><td><div id="flash_container_tt4fe051beada2d"></div><script type="text/javascript">
var flashMap = new SWFObject("http://24timezones.com/timescript/clock_digit_12.swf", "main", "160", "80", "7.0.22", "#FFFFFF", true)
flashMap.addParam("movie", "http://24timezones.com/timescript/clock_digit_12.swf");
flashMap.addParam("quality", "high");
flashMap.addParam("wmode", "transparent");
flashMap.addParam("flashvars", "color=blueblack&logo=1&city=815322");
flashMap.write("flash_container_tt4fe051beada2d");
</script></td></tr><tr><td style="text-align: center; font-weight: bold">
<a href="http://24timezones.com/world_directory/addis_ababa_local_time.php" target="_blank" title=" " style="text-decoration: none">
</a></td></tr></table>
            
			<div id="menubar1">
	
	
	  <ul id="menu">
        
        <li><a href="mission.php">Our Mission </a></li>
        
        
      </ul>
	  <ul id="menu">
        
        <li><a href="vission.php">Our Vission </a></li>
       
        
     
	  </ul>
	   
	  <ul id="menu">
        
        <li class="current"><a href="news.php">News </a></li>
       
        
     
	  </ul>
	  
			</div>
			
			
          </div><!--close sidebar_item--> 
        </div><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	<div>
      <ul class="slideshow">
        <li class="show"><img width="975" height="350" src="images/pc.jpg"/></li>
        <li><img width="975" height="350" src="images/pcz.jpg"/></li>
      </ul>   	 
	 </div>
	 
	  <div id="content1">
        <div class="content_item">
		  <p>&nbsp;</p>
		  <table width="612" height="195">
            <tr>
              <th scope="row">&nbsp;</th>
            </tr>
          </table>
		  <p>&nbsp;</p>
        </div>
	  </div>
	  <ul id="menu">
       
        <li class="style9  style18">
          <h2 class="style19">Copyright©2022 Jimma town Management System </h2>
        </li>
      </ul>
	  <!--close sidebar_container-->
    </div>
	<!--close sidebar-->
</body>
</html>
