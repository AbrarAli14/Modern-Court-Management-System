<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>
  <title>Web Based Court Information Management System</title>
  <meta name="description" content="free website template" />
  <meta name="keywords" content="enter your keywords here" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  <style type="text/css">
<!--
.style10 {
	color: #009933;
	font-size: 36px;
}
.style13 {
	color: #006666;
	font-size: 18px;
}
.style14 {font-style: italic; color: #00FFFF; font-weight: bold; }
.style17 {color: #00FFFF; font-size: 14px; }
.style18 {color: #FFFFFF;
	font-weight: bold;
	font-style: italic;
	font-size: medium;
}
-->
  </style>
</head>

<body>
  <div id="main">
    <div id="header">
      <!--close banner-->
     <img src="images/bew.jpg" alt="image1" width="1201" height="118"/></div>

    <!--close header-->

	<div id="menubar">
      <ul id="menu">
        <li class="current"><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us </a></li>
        <li><a href="cntct.php">Contact Us</a></li>
		   <li><a href="givecomment.php">Give comment</a></li>
        <li><a href="feedback.php">View feedback</a></li>
        <li><a href="login.php">Login</a></li>
        
      </ul>
    </div><!--close menubar-->	
    
<div id="site_content">		

	  <div class="sidebar_container">       
		<div class="sidebar">
          <div class="sidebar_item">
<body bgcolor=#9494B8>
<script type="text/javascript" src="http://www.24webclock.com/clock24.js"></script>
<table border="0" bgcolor=#0000FF cellspacing=2 cellpadding=4 class="clock24st" style="line-height:50px; line-width:215px; padding:0;">
<tr><td bgcolor=#000000 class="clock24std" style="font-family:bold; font-size:26px;"><a href=" ">
</a>
<b><a href="http://www.24webclock.com/" style="text-decoration:none;"><span class="clock24s" id="clock24_48332" style="color:white;"></b> </span></a></td></tr>
</table>
<script type="text/javascript">
var clock24_48332 = new clock24('48332',180,'%HH:%nn:%ss %P','en');
clock24_48332.daylight('ET'); clock24_48332.refresh();
</script></body>
            
			 <ul id="menu">
        
        <li><a href="mission.php">Our Mission </a></li>
        
        
      </ul>
	  
			 <ul id="menu">
        
        <li><a href="vission.php">Our Vission </a></li>
        </ul>
			 <p>&nbsp;</p>
			 <p>&nbsp;</p>
			 <p>&nbsp;</p>
			 <table width="220" height="36">
               <tr>
               
                       <p>&nbsp;</p>
                   </marquee>
                     </p></th>
               </tr>
               <tr>
                 <th width="230" height="347" colspan="2" scope="row"><marquee direction="up">
                   </marquee>
                     <marquee direction="up">
                     <p>&nbsp;</p>
                     </marquee></th>
               </tr>
             </table>
			 <p>&nbsp;</p>
            <p>&nbsp;</p>
          </div><!--close sidebar_item--> 
        </div><!--close sidebar--><!--close sidebar--><!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
        <!--close sidebar-->
      </div>
	  <!--close sidebar_container-->	
	<div>
      <ul class="slideshow">
    
       <li><img width="975" height="350" src="images/jimma.jpg"/></li>
		<li><img width="975" height="350" src="images/download.jpg"/></li>
		<li><img width="975" height="350" src="images/ima.jpg"/></li>
		<li><img width="975" height="350" src="images/do.jpg"/></li>
      </ul>   	 
  </div>
	 
	  <div id="content1">
        <div class="content_item">
		
		  <h1>Welcome To Our Website</h1> 
	      <p>The system based on the court information management system that improves the manual data processing. 
		  Court Information Management System is document management system or handling of data, dataflow system, 
		  court fee, appointment and also concern with a customers’ comment. There are two major types of cases. 
		  Those are civil law and criminal law. Each of them contains their own sub branches. In order to execute 
		  those cases some process takes place.</p>
		  <br style="clear:both"/></div>
		  
		  
		  
	  </div>
	  
  <ul class="style10" id="menu">
       
        <li class="style9 style14 style13">
          <h2 class="style13"align="center">Copyright©2022 Jimma town University Court Management System </h2>
        </li>
  </ul>
   	
	  <h2>
	    <!--close sidebar_container-->
    </h2>
</div>
	<!--close sidebar-->
</body>
</html>
