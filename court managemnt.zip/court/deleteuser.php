<?php
session_start();
include ('connection.php');
if($log != "log"){
	header ("Location: editua.php");
}
$ctrl = $_REQUEST['key'];
$SQL = "delete from account where User_id = '$ctrl'";
mysqli_query($conn,$SQL);
mysqli_close($conn);

print "<script>location.href = 'editua.php'</script>";
?>